#ifndef _MCARDAPI_H
#define _MCARDAPI_H

//
// MCARD APIs Data Types
//

// 1. MCARDCONTEXT

typedef SCARDHANDLE			MCARDCONTEXT;
typedef MCARDCONTEXT*		PMCARDCONTEXT;


// 2. MCARDHANDLE 

typedef SCARDHANDLE MCARDHANDLE;
typedef MCARDHANDLE* PMCARDHANDLE;


// 3. MCARD_FEATURES

typedef struct _MCARD_FEATURES
{
	DWORD	dwFlags;
	BYTE	byMemoryZones;
	BYTE	byPINs;
	BYTE	byCounters;
	BYTE	byCRs;
} MCARD_FEATURES, *PMCARD_FEATURES;


// 4. MCARD_MEMORY

typedef struct _MCARD_MEMORY 
{
	DWORD	dwFLags;
	DWORD	dwSize;
} MCARD_MEMORY, *PMCARD_MEMORY;


// 5. MCARD_PIN

typedef struct _MCARD_PIN 
{
	DWORD	dwFlags;
	BYTE	bySize;
	BYTE	byRetries;
} MCARD_PIN, *PMCARD_PIN;


// 6. MCARD_CR

typedef struct _MCARD_CR 
{
	DWORD	dwFlags;
	DWORD	dwChallengeLen;
	DWORD	dwResponseLen;
	BYTE	byRetries;
} MCARD_CR, *PMCARD_CR;


// 7. MCARD_COUNTER

typedef struct _MCARD_COUNTER 
{
	DWORD	dwFLags;
	BYTE	dwSize;
	DWORD	dwUnits;
} MCARD_COUNTER, *PMCARD_COUNTER;

// Memory card types
#define		MCARDTYPE_UNKNOWN				0x00
#define		MCARDTYPE_SLE4406				0x01
#define		MCARDTYPE_SLE4418				0x02
#define		MCARDTYPE_SLE4428				0x03
#define		MCARDTYPE_SLE4432				0x04
#define		MCARDTYPE_SLE4436				0x05
#define		MCARDTYPE_SLE4442				0x06
#define		MCARDTYPE_SLE5536				0x07
#define		MCARDTYPE_AT24C01ASC			0x08
#define		MCARDTYPE_AT24C02SC				0x09
#define		MCARDTYPE_AT24C04SC				0x0A
#define		MCARDTYPE_AT24C08SC				0x0B
#define		MCARDTYPE_AT24C16SC				0x0C
#define		MCARDTYPE_AT24C32SC				0x0D
#define		MCARDTYPE_AT24C64SC				0x0E
#define		MCARDTYPE_AT24C128SC			0x0F
#define		MCARDTYPE_AT24C256SC			0x10
#define		MCARDTYPE_AT24C512SC			0x11
#define		MCARDTYPE_AT88SC153				0x12
#define		MCARDTYPE_AT88SC1608			0x13


//
// Memory card protocols 
//
#define		PROTOCOL_UNKNOWN				0x00
#define		PROTOCOL_2_WIRE					0x01
#define		PROTOCOL_3_WIRE					0x02
#define		PROTOCOL_IIC					0x03
#define		PROTOCOL_EXT_IIC				0x04
#define		PROTOCOL_AT88_IIC				0x05
#define		PROTOCOL_SLE4406				0x06
#define		PROTOCOL_GENERIC				0xFF


// Attribute IDs
#define		MCARD_ATTR_TYPE					0x00
#define		MCARD_ATTR_PROTOCOL				0x01
#define		MCARD_ATTR_FEATURES				0x02
#define		MCARD_ATTR_MEMORY				0x03
#define		MCARD_ATTR_PIN					0x04
#define		MCARD_ATTR_CR					0x05
#define		MCARD_ATTR_COUNTERS				0x06
#define		MCARD_ATTR_CLOCK				0x07
#define		MCARD_ATTR_BIT_ORDER			0x08
#define		MCARD_ATTR_CONFIGURATION		0x09

// Bit order
#define		LSB								0x00
#define		MSB								0x01
#define		DEFAULT							0xFF

// Memory card specific error codes
#define		SCARD_CODE_BASE					0x80100000
#define		COSTOMER_CODE_FLAG				0x20000000
#define		MCARD_OFFSET					0x800

// Offset for error codes		
#define		MCARD_E_OFFSET					0x0

// Offset for warning codes [SCARD_W_xx uses same]
#define		MCARD_W_OFFSET					0x65 

#define		MCARD_CODE_BASE     ((SCARD_CODE_BASE | COSTOMER_CODE_FLAG) + MCARD_OFFSET)
#define		MCARD_E_CODE_BASE   (MCARD_CODE_BASE + MCARD_E_OFFSET) // errors start here
#define		MCARD_W_CODE_BASE   (MCARD_CODE_BASE + MCARD_W_OFFSET) // warning start here


// MCARD_E_xxx error codes *************************************

// These codes indicate the "bad" errors
#define		MCARD_S_SUCCESS						 0x00

// 0x90100801: an internal error has occured
#define		MCARD_E_INTERNAL_ERROR               MCARD_E_CODE_BASE + 0x1

// 0x90100802: function not implemented
#define		MCARD_E_NOT_IMPLEMENTED              MCARD_E_CODE_BASE + 0x2

// 0x90100803: MCardInitialize not called
#define		MCARD_E_NOT_INITIALIZED              MCARD_E_CODE_BASE + 0x3

// 0x90100804: this DLL does not work with the specified reader
#define		MCARD_E_INCOMPATIBLE_READER          MCARD_E_CODE_BASE + 0x4

// 0x90100805: could not identify card
#define		MCARD_E_UNKNOWN_CARD                 MCARD_E_CODE_BASE + 0x05

// 0x90100811: the buffer for return daa is too small
#define		MCARD_E_BUFFER_TOO_SMALL             MCARD_E_CODE_BASE + 0x11

// 0x90100812: one or more parameters are invalid
#define     MCARD_E_INVALID_PARAMETER            MCARD_E_CODE_BASE + 0x12

// 0x90100821: protocoll error while connecting to card
#define		MCARD_E_PROTO_MISMATCH               MCARD_E_CODE_BASE + 0x21

// 0x90100822: protocol error during card access
#define		MCARD_E_PROTOCOL_ERROR               MCARD_E_CODE_BASE + 0x22

// 0x90100827: Challenge Response Failed
#define		MCARD_E_CHAL_RESP_FAILED             MCARD_E_CODE_BASE + 0x23

// 0x90100826: Invalid memory range
#define		MCARD_E_INVALID_MEMORY_RANGE         MCARD_E_CODE_BASE + 0x24


// 0x90100831: specified memory zone ID is invalid for current card
#define		MCARD_E_INVALID_MEMORY_ZONE_ID       MCARD_E_CODE_BASE + 0x31

// 0x90100832: specified PIN ID is invalid for current card
#define		MCARD_E_INVALID_PIN_ID               MCARD_E_CODE_BASE + 0x32

// 0x90100833: spezcified challenge/response ID is invalid for current card
#define		MCARD_E_INVALID_CHAL_RESP_ID         MCARD_E_CODE_BASE + 0x33


// MCARD_W_xxx warning codes *************************************************
// These codes indicate that a problem occured, but it's up to the
//   application to decide how bad it is

// 0x90100866: could not read all data from card
#define		MCARD_W_NOT_ALL_DATA_READ            MCARD_W_CODE_BASE + 0x1

// 0x90100867: could not write all data to card
#define		MCARD_W_NOT_ALL_DATA_WRITTEN         MCARD_W_CODE_BASE + 0x2

// 0x90100876: PIN must be verified before access is possible
#define		MCARD_W_PIN_VERIFY_NEEDED            MCARD_W_CODE_BASE + 0x11

// 0x90100877: PIN verification failed
#define		MCARD_W_PIN_VERIFY_FAILED            MCARD_W_CODE_BASE + 0x12

// 0x90100878: no PIN verification attempts left, card probably locked
#define		MCARD_W_NO_PIN_ATTEMPTS_LEFT         MCARD_W_CODE_BASE + 0x13

//no Units to Decrement in the counter
#define     MCARD_W_NO_UNITS_TO_DECREMENT        MCARD_W_CODE_BASE+0x14

// 0xA0100886: The card has been removed
#define		MCARD_W_REMOVED_CARD				 MCARD_W_CODE_BASE + 0x21

#endif

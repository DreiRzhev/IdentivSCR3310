#ifndef __STDINC_H_INCLUDED__

#define __STDINC_H_INCLUDED__

	#include <initguid.h>
	#include <setupapi.h>
	#include <winioctl.h>
	#include <winsvc.h>
	#include <process.h>

	#include "resource.h"

#endif
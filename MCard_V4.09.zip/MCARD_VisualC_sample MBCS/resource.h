//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Mcard.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MCARD_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDC_LOAD                        1001
#define IDC_STATUS                      1002
#define IDC_MCINIT                      1003
#define Exit                            1004
#define IDC_MEMBUFFER                   1006
#define IDC_CRBUFFER                    1007
#define IDC_CBUFFER                     1007
#define IDC_CONNECT                     1008
#define IDC_DISCONNECT                  1009
#define IDC_GETATTRIB                   1010
#define IDC_READMEM                     1011
#define IDC_SETATTRIB                   1012
#define IDC_WRITEMEM                    1013
#define IDC_READMEMSTAT                 1014
#define IDC_PROTECTREAD                 1015
#define IDC_MEMZONE                     1016
#define IDC_PROTECTWRITE                1017
#define IDC_VERIFYPIN                   1018
#define IDC_CHANGEPIN                   1019
#define IDC_GETRESPONSE                 1020
#define IDC_MEMOFFSET                   1021
#define IDC_RBUFFER                     1022
#define IDC_MEMLEN                      1023
#define IDC_CHALLENGELEN                1024
#define IDC_CHALLENGEID                 1025
#define IDC_COUNTER                     1026
#define IDC_SHUTDOWN                    1027
#define IDC_MEMINIT                     1028
#define IDC_PINNUM                      1031
#define IDC_CURPIN                      1032
#define IDC_CURPINLEN                   1036
#define IDC_BITORDER                    1040
#define IDC_READER_NAMES                1041
#define IDC_NEWPIN                      1042
#define IDC_NEWPINLEN                   1043
#define IDC_PROTOCOL                    1044
#define IDC_TYPE                        1045
#define IDC_ZONES                       1046
#define IDC_PINS                        1047
#define IDC_DETAILS                     1048
#define IDC_CLOCKRATE                   1050
#define IDC_PAGESIZE                    1051
#define IDC_AUTODETECT                  1052
#define IDC_CARDTYPE                    1053
#define IDC_COUNTERS                    1054
#define IDC_CRS                         1055
#define IDC_CLEAR                       1057
#define IDC_BUTTON1                     1061
#define IDC_ATTRS                       1063
#define IDC_CARDTIMEOUT                 1065
#define IDC_CARDSTATEENABLE             1067
#define IDC_EXPCARDSTATE                1068
#define IDC_CARDSTATUS                  1069

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1070
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
